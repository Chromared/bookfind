<?php require 'actions/database.php'; 
      require 'actions/users/securityAction.php';
      require 'actions/users/showOneUsersProfilAction.php';
      require 'actions/fonctions/transfoGradeIntVersText.php';
      require 'actions/fonctions/tradDateJourEnVersFr.php';
      require 'actions/fonctions/transDateMoisIntVersLettre.php';?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'includes/header.php' ?>
</head>
<body>
    <?php include 'includes/navbar.php'?>
    <?php if (isset($_GET['id'])) { ?>
    <?php

    if($selectInfosFromUsers->rowCount() >= 1){
?>
<div class="contour">
<div class="profil-info-page">
<div class="user-name"><br><h4><?= $usersInfos['prenom']; ?> <?= $usersInfos['nom']; ?></h4></div>
<div class="user-infos">
    <p>
        ID : <?= $usersInfos['id']; ?><br />
        Numéro de carte : <?= $usersInfos['carte']; ?><br />
        Classe : <?= $usersInfos['classe']; ?><br />
        Date d'inscription : Le <?php DateJour($usersInfos['date_j_lettre']); ?> <?= $usersInfos['date_j'] ?> <?php DateMois($usersInfos['date_m']); ?> à <?= $usersInfos['heure_h'] ?>:<?= $usersInfos['heure_m'] ?>:<?= $usersInfos['heure_s'] ?><br />
        Grade : <?php Grade($usersInfos['grade']); ?><br />
    </p>
    <?php if ($usersInfos['id'] == $_SESSION['id']){ ?>
    <p>
            <div class="profil-part">
            <button onclick="location.href='actions/users/logoutAction.php'">Se déconnecter</button>
            <button onclick="location.href='updateProfil.php?id=<?= $_SESSION['id'] ?>'">Modifier le compte</button>
            </div>
    </p>
    <?php } ?>
</div>
</div>
<?php }else{ echo '<div class="msg msg-blue>"Aucun utilisateur avec l\'id n°' . $_GET["id"] . ' n\'a été trouvé.</div>'; }} ?>
</div>
</body>
</html>