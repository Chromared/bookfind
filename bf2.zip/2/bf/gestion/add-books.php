<?php require '../actions/database.php'; 
      require '../actions/users/securityAction.php';
      require 'actions/securityActionAdmin.php';
      require 'actions/books/addBooksAction.php';
      require 'actions/books/addAuthorsAction.php';
      require 'actions/books/addEditeurAction.php';
      require 'actions/books/addGenresActions.php';
      require 'actions/books/addTypesAction.php'; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include '../includes/header.php'; ?>
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<p>
Les champs marqués d'une * sont obligatoires.
<fieldset><legend>Ajouter un livre</legend>
<form method="post">
<label>Titre* : </label><input type="text" name="title"/><br />
<label>Auteur* : </label><select name="author"><option value="Aucun" selected>Aucun</option><?php include 'actions/books/list-author.php'; ?></select><br />
<label>ISBN* : </label><input type="number" name="isbn"/><br />
<label>Identifiant unique : </label><input type="text" name="id_unique"/><br />
<label>Résumé : </label><textarea name="resume"></textarea><br />
<label>Éditeur* : </label><select name="editeur"><option value="Aucun" selected>Aucun</option><?php include 'actions/books/list-editeur.php'; ?></select><br />
<label>Genre : </label><select name="genre"><option value="Aucun" selected>Aucun</option><?php include 'actions/books/list-genre.php'; ?></select><br />
<label>Type* : </label><select name="type"><option value="Aucun" selected>Aucun</option><?php include 'actions/books/list-type.php'; ?></select><br />
<label>Quantité* : </label><input type="number" value="1" min="1" name="quantite"/><br />
<label>Série : </label><input type="text" name="serie" /><br />
<label>Tome : </label><input type="number" name="tome" /><br />
<input type="submit" name="validate" value="Enregistrer"/>
</form>
</fieldset>

<fieldset><legend>Ajouter un auteur</legend>
<form method="post">
<label>Prénom* : </label><input type="text" name="firstname"/> <label>Nom* : </label><input type="text" name="name"/> <label>Biographie : </label><textarea name="bio"></textarea> <input type="submit" value="Enregistrer" name="validateAuthor"/>
</form>
</fieldset>

<fieldset><legend>Ajouter un éditeur</legend>
<form method="post">
<label>Nom* : </label><input type="text" name="name"/> <input type="submit" value="Enregistrer" name="validateEditeur"/>
</form>
</fieldset>

<fieldset><legend>Ajouter un genre</legend>
<form method="post">
<label>Nom* : </label><input type="text" name="name"/> <input type="submit" value="Enregistrer" name="validateGenre"/>
</form>
</fieldset>

<fieldset><legend>Ajouter un type</legend>
<form method="post">
<label>Nom* : </label><input type="text" name="name"/> <input type="submit" value="Enregistrer" name="validateType"/>
</form>
</fieldset>
</p>
</body>
</html>