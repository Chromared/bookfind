<?php require '../actions/database.php';
    require '../actions/users/securityAction.php';
    require 'actions/securityActionAdmin.php';
    require 'actions/books/addEmpruntAction.php'; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include '../includes/header.php'; ?>
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<fieldset><legend>Ajouter un emprunt</legend>
<form method="post">
<label>N° de carte de l'emprunteur : </label><input type="number" name="card"/><br />
<label>À rendre pour le : </label><input type="date" name="date_retour" /><br />
<input type="hidden" name="id_book" value="<?= $_GET['id'] ?>" />
<input type="submit" name="validate" value="Ajouter l'emprunt"/>
</form>
</fieldset>
</body>
</html>