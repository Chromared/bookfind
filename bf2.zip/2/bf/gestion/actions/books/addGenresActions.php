<?php if(isset($_POST['validateGenre'])){
    if(isset($_POST['name'])){
    if(!empty($_POST['name']))

        $name = htmlspecialchars($_POST['name']);

        $addEditeur = $bdd->prepare('INSERT INTO genres SET nom = ?');
        $addEditeur->execute(array($name));

        header('Location: add-books.php');

    }
}