<?php
        $genres = $bdd->query('SELECT * FROM editeurs ORDER BY nom');

        while($list = $genres->fetch()){ ?>
        <option value="<?= $list['nom']; ?>"><?= $list['nom']; ?></option>
<?php }