<?php if(isset($_POST['validate'])){
    if(isset($_POST['card']) AND isset($_POST['date_retour']) AND isset($_POST['id_book'])){
        if(!empty($_POST['card']) AND !empty($_POST['date_retour']) AND !empty($_POST['id_book'])){

            $card = htmlspecialchars($_POST['card']);
            $date_retour = htmlspecialchars($_POST['date_retour']);
            $id_book = htmlspecialchars($_POST['id_book']);

            

        }
    }
}