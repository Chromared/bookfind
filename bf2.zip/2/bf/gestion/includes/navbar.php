<div class="navbar">
<div class="">
    <nav>

    
        <ul class="sidebar">
            <li onclick=hideSidebar()><a href="#"><svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg></a></li>
            <li><a href="index.php">Accueil</a></li>

            <li><a href="../index.php">Quitter la Gestion</a></li>
            <li class="li-nav"><a href="books.php">Livres</a></li>

            <li><a href="users.php">Utilisateurs</a></li>

            <?php if ($_SESSION['grade'] == '1') { ?>
                <li><a href="log.php">Logs</a></li>
            <?php } ?>

        </ul>
        <ul>
            <li><a href="index.php"><img src="../style/img/logopourpage.png" alt="logo" class="logo"></a></li>
            <li class="hideOnMobile"><a href="index.php">Accueil</a></li>

                <li class="hideOnMobile"><a href="../index.php">Quitter la gestion</a></li>
                <li class="hideOnMobile"><a href="books.php">Livres</a></li>

                <li class="hideOnMobile"><a href="users.php">Utilisateurs</a></li>

            <?php if ($_SESSION['grade'] == '1') { ?>
                <li class="hideOnMobile"><a href="log.php">Logs</a></li>
            <?php } ?>

                <li class="menu-button" onclick=showSidebar()><a href="#"><svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z"/></svg></a></li>
        </ul>
    </nav>
    <script>
        function showSidebar() {
            const sidebar = document.querySelector('.sidebar')
            sidebar.style.display = 'flex'
        }
        function hideSidebar() {
            const sidebar = document.querySelector('.sidebar')
            sidebar.style.display = 'none'
        }
    </script>
</div>
</div>