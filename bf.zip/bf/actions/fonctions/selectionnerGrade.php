<?php
function Grade($grade, $usersgrade) {

    if ($grade == $usersgrade) {
        echo'selected="selected"';
}
}