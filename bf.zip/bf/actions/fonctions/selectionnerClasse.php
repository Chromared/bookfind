<?php
function Classe($classe, $usersclasse) {

    if ($classe == $usersclasse) {
        echo'selected="selected"';
}
}