<?php
if($_SESSION['grade'] == '0'){
    header('Location: ../index.php');
}