<?php if(isset($_POST['validate'])){
    if(isset($_POST['title']) AND isset($_POST['author']) AND isset($_POST['isbn']) AND isset($_POST['editeur']) AND isset($_POST['type']) AND isset($_POST['quantite'])){
        if(!empty($_POST['title']) AND !empty($_POST['author']) AND !empty($_POST['isbn']) AND !empty($_POST['editeur']) AND !empty($_POST['type']) AND !empty($_POST['quantite'])){

            $title = htmlspecialchars($_POST['title']);
            $author = htmlspecialchars($_POST['author']);
            $isbn = htmlspecialchars($_POST['isbn']);
            $editeur = htmlspecialchars($_POST['editeur']);
            $type = htmlspecialchars($_POST['type']);
            $quantite = htmlspecialchars($_POST['quantite']);

            if(isset($_POST['resume']) AND !empty($_POST['resume'])){
                $resume = htmlspecialchars($_POST['resume']);
            }else{$resume = false;}

            if(isset($_POST['genre']) AND !empty($_POST['genre'])){
                $genre = htmlspecialchars($_POST['genre']);
            }else{$genre = false;}

            if(isset($_POST['id_unique']) AND !empty($_POST['id_unique'])){

                $id_unique = htmlspecialchars($_POST['id_unique']);

                $checkIfIdUniqueAlreadyExists = $bdd->prepare('SELECT id_unique FROM books WHERE id_unique = ?');
                $checkIfIdUniqueAlreadyExists->execute(array($id_unique));

                if($checkIfIdUniqueAlreadyExists->rowCount() == 0){

                $id_u = true;

                }

            }else{$id_unique = false; $id_u = true;}

            if(isset($_POST['serie']) AND isset($_POST['tome']) AND !empty($_POST['serie']) AND !empty($_POST['tome'])){
                $serie = htmlspecialchars($_POST['serie']);
                $tome = htmlspecialchars($_POST['tome']);
            }else{$serie = false; $tome = false;}

            if($id_u = true){

                $addBook = $bdd->prepare('INSERT INTO books SET titre = ?, auteur = ?, isbn = ?, id_unique = ?, editeur = ?, type = ?, quantite = ?, resume = ?, genre = ?, serie = ?, tome = ?');
                $addBook->execute(array($title, $author, $isbn, $id_unique, $editeur, $type, $quantite, $resume, $genre, $serie, $tome));

                header('Location: add-books.php');
            }


        }
    }
}