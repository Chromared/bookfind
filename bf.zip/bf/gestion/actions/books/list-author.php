<?php
        $authors = $bdd->query('SELECT * FROM authors ORDER BY nom');

        while($list = $authors->fetch()){ ?>
        <option value="<?= $list['prenom']; ?> <?= $list['nom']; ?>"><?= $list['prenom']; ?> <?= $list['nom']; ?></option>
<?php }