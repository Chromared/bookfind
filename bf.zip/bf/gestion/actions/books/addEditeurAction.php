<?php if(isset($_POST['validateEditeur'])){
    if(isset($_POST['name'])){
    if(!empty($_POST['name']))

        $name = htmlspecialchars($_POST['name']);

        $addEditeur = $bdd->prepare('INSERT INTO editeurs SET nom = ?');
        $addEditeur->execute(array($name));

        header('Location: add-books.php');

    }
}