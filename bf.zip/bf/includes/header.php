<title>BookFind</title>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
<link rel="icon" href="style/img/iconesite.ico" />
<link rel="icon" href="../style/img/iconesite.ico" />
<script src="https://kit.fontawesome.com/36a4c41322.js" crossorigin="anonymous"></script>
<link href="style/style0.css" rel="stylesheet">
<link href="../style/style0.css" rel="stylesheet">